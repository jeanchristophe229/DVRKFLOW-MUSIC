# DVRKFLOW MUSIC — Site vitrine

Version légère, responsive et orientée éco-conception.

## Structure
- index.html
- css/style.css
- js/main.js
- assets/logo.webp
- assets/favicon.webp

## Mise en ligne
1. Décompresser le dossier.
2. Envoyer tout le contenu sur votre hébergement.
3. Garder les chemins relatifs tels quels.

Le site fonctionne sans framework ni build.
Il peut être hébergé sur un hébergement statique classique.

## Formulaire
Le formulaire utilise `mailto:` afin de rester sans backend.
Pour un vrai traitement serveur (stockage, anti-spam, accusé de réception),
remplacez la partie concernée dans `js/main.js` par votre service/API.

## Éco-conception
- pas de framework JS
- pas de police externe
- logo optimisé en WebP
- pas de vidéo automatique
- CSS natif
- JavaScript vanilla
- peu de requêtes
- animations légères
- prise en charge de prefers-reduced-motion
- structure single-page
